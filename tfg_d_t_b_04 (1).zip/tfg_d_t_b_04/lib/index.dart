// Export pages
export '/inicrear/ini/ini_widget.dart' show IniWidget;
export '/inicrear/crear/crear_widget.dart' show CrearWidget;
export '/ajustes/ajustes/ajustes_widget.dart' show AjustesWidget;
export '/ajustes/biojuga/biojuga_widget.dart' show BiojugaWidget;
export '/ajustes/crearanuncio/crearanuncio_widget.dart' show CrearanuncioWidget;
export '/chat/chat_inter/chat_inter_widget.dart' show ChatInterWidget;
export '/chat/chat/chat_widget.dart' show ChatWidget;
export '/chat/ssssssssssss/ssssssssssss_widget.dart' show SsssssssssssWidget;
export '/listas/equiposlist/equiposlist_widget.dart' show EquiposlistWidget;
export '/ajustes/jugadorespos/jugadorespos_widget.dart' show JugadoresposWidget;
export '/listas/posiciones/delanteros/delanteros_widget.dart'
    show DelanterosWidget;
export '/listas/posiciones/medios/medios_widget.dart' show MediosWidget;
export '/listas/posiciones/defensas/defensas_widget.dart' show DefensasWidget;
export '/listas/posiciones/porteros/porteros_widget.dart' show PorterosWidget;
export '/ajustes/cuestionario/cuestionario_widget.dart' show CuestionarioWidget;
