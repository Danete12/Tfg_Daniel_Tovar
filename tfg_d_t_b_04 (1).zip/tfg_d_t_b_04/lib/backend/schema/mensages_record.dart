import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MensagesRecord extends FirestoreRecord {
  MensagesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "chatID" field.
  String? _chatID;
  String get chatID => _chatID ?? '';
  bool hasChatID() => _chatID != null;

  // "text" field.
  String? _text;
  String get text => _text ?? '';
  bool hasText() => _text != null;

  // "time_msg" field.
  DateTime? _timeMsg;
  DateTime? get timeMsg => _timeMsg;
  bool hasTimeMsg() => _timeMsg != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "userID" field.
  String? _userID;
  String get userID => _userID ?? '';
  bool hasUserID() => _userID != null;

  void _initializeFields() {
    _chatID = snapshotData['chatID'] as String?;
    _text = snapshotData['text'] as String?;
    _timeMsg = snapshotData['time_msg'] as DateTime?;
    _type = snapshotData['type'] as String?;
    _userID = snapshotData['userID'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('mensages');

  static Stream<MensagesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MensagesRecord.fromSnapshot(s));

  static Future<MensagesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MensagesRecord.fromSnapshot(s));

  static MensagesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MensagesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MensagesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MensagesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MensagesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MensagesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMensagesRecordData({
  String? chatID,
  String? text,
  DateTime? timeMsg,
  String? type,
  String? userID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'chatID': chatID,
      'text': text,
      'time_msg': timeMsg,
      'type': type,
      'userID': userID,
    }.withoutNulls,
  );

  return firestoreData;
}

class MensagesRecordDocumentEquality implements Equality<MensagesRecord> {
  const MensagesRecordDocumentEquality();

  @override
  bool equals(MensagesRecord? e1, MensagesRecord? e2) {
    return e1?.chatID == e2?.chatID &&
        e1?.text == e2?.text &&
        e1?.timeMsg == e2?.timeMsg &&
        e1?.type == e2?.type &&
        e1?.userID == e2?.userID;
  }

  @override
  int hash(MensagesRecord? e) => const ListEquality()
      .hash([e?.chatID, e?.text, e?.timeMsg, e?.type, e?.userID]);

  @override
  bool isValidKey(Object? o) => o is MensagesRecord;
}
