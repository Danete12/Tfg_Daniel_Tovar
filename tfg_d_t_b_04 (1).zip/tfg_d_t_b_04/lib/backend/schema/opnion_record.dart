import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OpnionRecord extends FirestoreRecord {
  OpnionRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Pregunta1" field.
  String? _pregunta1;
  String get pregunta1 => _pregunta1 ?? '';
  bool hasPregunta1() => _pregunta1 != null;

  // "Pregunta2" field.
  String? _pregunta2;
  String get pregunta2 => _pregunta2 ?? '';
  bool hasPregunta2() => _pregunta2 != null;

  // "Pregunta3" field.
  String? _pregunta3;
  String get pregunta3 => _pregunta3 ?? '';
  bool hasPregunta3() => _pregunta3 != null;

  // "Pregunta4" field.
  String? _pregunta4;
  String get pregunta4 => _pregunta4 ?? '';
  bool hasPregunta4() => _pregunta4 != null;

  // "Opinion" field.
  String? _opinion;
  String get opinion => _opinion ?? '';
  bool hasOpinion() => _opinion != null;

  void _initializeFields() {
    _pregunta1 = snapshotData['Pregunta1'] as String?;
    _pregunta2 = snapshotData['Pregunta2'] as String?;
    _pregunta3 = snapshotData['Pregunta3'] as String?;
    _pregunta4 = snapshotData['Pregunta4'] as String?;
    _opinion = snapshotData['Opinion'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('opnion');

  static Stream<OpnionRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OpnionRecord.fromSnapshot(s));

  static Future<OpnionRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OpnionRecord.fromSnapshot(s));

  static OpnionRecord fromSnapshot(DocumentSnapshot snapshot) => OpnionRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OpnionRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OpnionRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OpnionRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OpnionRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOpnionRecordData({
  String? pregunta1,
  String? pregunta2,
  String? pregunta3,
  String? pregunta4,
  String? opinion,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Pregunta1': pregunta1,
      'Pregunta2': pregunta2,
      'Pregunta3': pregunta3,
      'Pregunta4': pregunta4,
      'Opinion': opinion,
    }.withoutNulls,
  );

  return firestoreData;
}

class OpnionRecordDocumentEquality implements Equality<OpnionRecord> {
  const OpnionRecordDocumentEquality();

  @override
  bool equals(OpnionRecord? e1, OpnionRecord? e2) {
    return e1?.pregunta1 == e2?.pregunta1 &&
        e1?.pregunta2 == e2?.pregunta2 &&
        e1?.pregunta3 == e2?.pregunta3 &&
        e1?.pregunta4 == e2?.pregunta4 &&
        e1?.opinion == e2?.opinion;
  }

  @override
  int hash(OpnionRecord? e) => const ListEquality().hash(
      [e?.pregunta1, e?.pregunta2, e?.pregunta3, e?.pregunta4, e?.opinion]);

  @override
  bool isValidKey(Object? o) => o is OpnionRecord;
}
