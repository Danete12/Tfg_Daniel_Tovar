import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatsRecord extends FirestoreRecord {
  ChatsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "chatID" field.
  String? _chatID;
  String get chatID => _chatID ?? '';
  bool hasChatID() => _chatID != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  bool hasTime() => _time != null;

  // "ult_msg" field.
  String? _ultMsg;
  String get ultMsg => _ultMsg ?? '';
  bool hasUltMsg() => _ultMsg != null;

  // "ult_msg_time" field.
  DateTime? _ultMsgTime;
  DateTime? get ultMsgTime => _ultMsgTime;
  bool hasUltMsgTime() => _ultMsgTime != null;

  // "userA" field.
  String? _userA;
  String get userA => _userA ?? '';
  bool hasUserA() => _userA != null;

  // "userB" field.
  String? _userB;
  String get userB => _userB ?? '';
  bool hasUserB() => _userB != null;

  void _initializeFields() {
    _chatID = snapshotData['chatID'] as String?;
    _email = snapshotData['email'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _time = snapshotData['time'] as DateTime?;
    _ultMsg = snapshotData['ult_msg'] as String?;
    _ultMsgTime = snapshotData['ult_msg_time'] as DateTime?;
    _userA = snapshotData['userA'] as String?;
    _userB = snapshotData['userB'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('chats');

  static Stream<ChatsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatsRecord.fromSnapshot(s));

  static Future<ChatsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChatsRecord.fromSnapshot(s));

  static ChatsRecord fromSnapshot(DocumentSnapshot snapshot) => ChatsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatsRecordData({
  String? chatID,
  String? email,
  String? photoUrl,
  DateTime? time,
  String? ultMsg,
  DateTime? ultMsgTime,
  String? userA,
  String? userB,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'chatID': chatID,
      'email': email,
      'photo_url': photoUrl,
      'time': time,
      'ult_msg': ultMsg,
      'ult_msg_time': ultMsgTime,
      'userA': userA,
      'userB': userB,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatsRecordDocumentEquality implements Equality<ChatsRecord> {
  const ChatsRecordDocumentEquality();

  @override
  bool equals(ChatsRecord? e1, ChatsRecord? e2) {
    return e1?.chatID == e2?.chatID &&
        e1?.email == e2?.email &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.time == e2?.time &&
        e1?.ultMsg == e2?.ultMsg &&
        e1?.ultMsgTime == e2?.ultMsgTime &&
        e1?.userA == e2?.userA &&
        e1?.userB == e2?.userB;
  }

  @override
  int hash(ChatsRecord? e) => const ListEquality().hash([
        e?.chatID,
        e?.email,
        e?.photoUrl,
        e?.time,
        e?.ultMsg,
        e?.ultMsgTime,
        e?.userA,
        e?.userB
      ]);

  @override
  bool isValidKey(Object? o) => o is ChatsRecord;
}
