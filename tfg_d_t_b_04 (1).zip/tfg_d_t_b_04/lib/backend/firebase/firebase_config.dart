import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDHF-ij-HPk8Enxs3pDKCWy8kxVTiLJERQ",
            authDomain: "pidod-2x7le6.firebaseapp.com",
            projectId: "pidod-2x7le6",
            storageBucket: "pidod-2x7le6.appspot.com",
            messagingSenderId: "816553173093",
            appId: "1:816553173093:web:2900b75c816540e756268c"));
  } else {
    await Firebase.initializeApp();
  }
}
